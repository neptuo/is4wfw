function cancelAnswer() {
	document.getElementById('guestbook-parent').value = 0;
	document.getElementById('guestbook-answer-notify').style.display = 'none';
}