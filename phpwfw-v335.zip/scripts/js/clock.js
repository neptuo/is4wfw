// JavaScript Document

function Clock() {
	
}