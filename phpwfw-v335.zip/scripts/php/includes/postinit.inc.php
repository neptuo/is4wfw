<?php

	/**
	 *
	 *	Script inluded after app init
	 *
	 */
	$webObject->setZipOutput(true);

?>