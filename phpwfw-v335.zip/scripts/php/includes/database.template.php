<?php
define("WEB_DB_HOSTNAME", "{hostname}");
define("WEB_DB_USER", "{username}");
define("WEB_DB_PASSWORD", "{password}");
define("WEB_DB_DATABASE", "{database}");
?>