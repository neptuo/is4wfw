<?php

/**
 *
 * 	Build version
 *
 */
define("BUILD_VERSION", 335);

/**
 *
 * 	Web framework version.
 *
 */
define("WEB_VERSION", "1.9.27." . BUILD_VERSION);

/**
 *
 * 	Cms framework version.
 *
 */
define("CMS_VERSION", "5.06");

?>
