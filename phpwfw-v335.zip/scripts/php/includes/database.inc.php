<?php
define("WEB_DB_HOSTNAME", "127.0.0.1");
define("WEB_DB_USER", "neptuo.com");
define("WEB_DB_PASSWORD", "QTnF85s7");
define("WEB_DB_DATABASE", "neptuocom2");
?>