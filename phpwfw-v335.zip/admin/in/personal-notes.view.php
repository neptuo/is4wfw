<v:template src="~/templates/in-template.view">
	<sys:manageNotes />
</v:template>
