<v:template src="~/templates/in-template.view">
	<php:using prefix="pg" class="php.libs.Page">
		<pg:manageUrlCache />
	</php:using>
</v:template>