<v:template src="~/templates/in-template.view">
	<v:panel security:requireGroup="admins">
		<sys:editConnection />
		<sys:listConnections />
	</v:panel>
</v:template>