<v:template src="~/templates/in-template.view">
	<web:a pageId="~/in/personal-properties.view" text="&laquo; Your properties" />

	<sys:manageProperties userId="default" />
</v:template>
