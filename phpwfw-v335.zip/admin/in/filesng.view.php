<v:template src="~/templates/in-template.view">
	<fa:upload />
	<fa:directoryEditor />
	<fa:browser />
</v:template>