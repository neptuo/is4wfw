<v:template src="~/templates/in-template.view">
	<php:using prefix="applog" class="php.libs.ApplicationLog">
		<applog:log />
		<applog:list />
	</php:using>
</v:template>