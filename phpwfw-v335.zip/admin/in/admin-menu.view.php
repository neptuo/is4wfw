<v:template src="~/templates/in-template.view">
	<sys:adminMenuItem />
</v:template>