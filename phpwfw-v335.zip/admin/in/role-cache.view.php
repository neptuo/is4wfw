<v:template src="~/templates/in-template.view">
	<sys:manageRoleCache />
</v:template>