<v:template src="~/templates/in-template.view">
	<web:a pageId="~/in/default-properties.view" text="&laquo; Default properties" />

	<sys:manageProperties userId="current" />
</v:template>
