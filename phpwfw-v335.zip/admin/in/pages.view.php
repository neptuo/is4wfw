<v:template src="~/templates/in-template.view">
	<php:using prefix="pg" class="php.libs.Page">
		<pg:pageProperties />
		<pg:showEditPage />
		<pg:showList editable="true" />
	</php:using>
</v:template>