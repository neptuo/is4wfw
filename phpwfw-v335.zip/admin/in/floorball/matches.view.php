<v:template src="~/templates/floorball-template.view">
  <sport:editStatsForm />
  <sport:editMatchForm />
	<sport:editMatches />
</v:template>