<v:template src="~/templates/floorball-template.view">
    <sport:editTeamForm />
    <sport:editTeams />
    <sport:copyTeamTableStats />
</v:template>