<v:template src="~/templates/floorball-template.view">
    <sport:table editable="true" />
</v:template>