<v:template src="~/templates/floorball-template.view">
    <sport:editTableForm />
    <sport:editTables />
</v:template>