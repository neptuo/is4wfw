<v:template src="~/templates/floorball-template.view">
  <sport:editPlayerForm />
	<sport:editPlayers />
</v:template>