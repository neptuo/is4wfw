<v:template src="~/templates/floorball-template.view">
  <sport:editSeasonForm />
	<sport:editSeasons />
</v:template>