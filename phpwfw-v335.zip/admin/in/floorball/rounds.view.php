<v:template src="~/templates/floorball-template.view">
	<sport:editRoundForm />
	<sport:editRounds />
</v:template>