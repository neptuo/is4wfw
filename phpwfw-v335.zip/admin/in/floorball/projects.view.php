<v:template src="~/templates/floorball-template.view">
	<sport:editProjectForm />
	<sport:editProjects />
</v:template>