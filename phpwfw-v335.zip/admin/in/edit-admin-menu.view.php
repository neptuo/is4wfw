<v:template src="~/templates/in-template.view">
	<v:panel security:requirePerm="CMS.Settings.AdminMenu">
		<sys:editAdminMenu />
	</v:panel>
</v:template>