<v:template src="~/templates/article-template.view">
  <a href="~/in/article-lines.view">&laquo; Back to article line list</a>
  <artc:editLine />
</v:template>