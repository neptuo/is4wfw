<v:template src="~/templates/in-template.view">
	<wp:showEditForm showNotSelectedError="false" />
	<wp:showProjects editable="true" />
</v:template>