<v:template src="~/templates/in-template.view">
	<php:using prefix="pg" class="php.libs.Page">
		<pg:updateKeywords />
		<pg:updateRobots />
	</php:using>
</v:template>