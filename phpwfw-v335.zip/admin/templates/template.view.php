<v:title value="is4wfw" />
<login:init group="web-admins" />
<v:resource type="css" src="~/css/cms.css" />
<v:content />