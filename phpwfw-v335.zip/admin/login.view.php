<v:template src="~/templates/template.view">
	<div class="login-icons">
		<img src="~/images/icons/service/rssmm_wfw.png" width="80" height="15" />
	  	<img src="~/images/icons/service/ctags_php.png" width="80" height="15" />
	  	<hr />
	  	<img src="~/images/icons/service/valid_xhtml.png" width="80" height="15" />
	  	<img src="~/images/icons/service/valid_css.png" width="80" height="15" />
	  	<hr />
	  	<img src="~/images/icons/service/firefox_copy2.gif" width="80" height="15" />
	  	<img src="~/images/icons/service/opera.gif" width="80" height="15" />
	  	<img src="~/images/icons/service/safari_copy2.gif" width="80" height="15" />
	  	<hr />
	  	<img src="~/images/icons/service/1024768.gif" width="80" height="15" />
		<img src="~/images/icons/service/12801024.gif" width="80" height="15" />
	  	<img src="~/images/icons/service/16001200.gif" width="80" height="15" />
	</div>
	<div class="login">
		<div class="login-head"></div>
		<div class="login-in">
			<login:form group="web-admins" pageId="~/in/index.view" />
		</div>
	</div>
	<script type="text/javascript" src="~/js/domready.js"></script>
	<script type="text/javascript" src="~/js/formFieldEffect.js"></script>
	<script type="text/javascript" src="~/js/initLogin.js"></script>
</v:template>
