<?php
	//+ěščřžýáíéúů
	
	$value = 'category:cf:rowId';
	
	$f = explode(':', $value, 2);
	
	print_r($f);
	
?>